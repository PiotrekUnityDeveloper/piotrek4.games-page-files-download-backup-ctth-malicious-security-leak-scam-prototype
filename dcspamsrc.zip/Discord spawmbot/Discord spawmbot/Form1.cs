﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Discord_spawmbot
{
    public partial class Form1 : Form
    {
        public int countdown = 0;
        public int entercountdown = 0;

        public int rndnumbercountdown = 0;
        Random rndnum = new Random();

        public int order = 0;

        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedItem = "full text";
            comboBox2.SelectedItem = "From List";

            this.Size = new System.Drawing.Size(578, 251);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            

            if(radioButton2.Checked == true) //single
            {
                SendKeys.Send(richTextBox1.SelectedText);
                richTextBox1.SelectionStart += 1;
                countdown -= 1;
                entercountdown -= 1;

                if (comboBox1.SelectedItem == "each letter" && checkBox1senderauto.Checked == true)
                {
                    SendKeys.Send("{ENTER}");
                }
                else if (comboBox1.SelectedItem == "each word" && checkBox1senderauto.Checked == true)
                {
                    if (richTextBox1.SelectedText == " ")
                    {
                        SendKeys.Send("{ENTER}");
                    }
                }
                else if (entercountdown < 1 && comboBox1.SelectedItem == "full text" && checkBox1senderauto.Checked == true && isslide.Checked == true)
                {
                    SendKeys.Send("{ENTER}");
                    entercountdown = (richTextBox1.TextLength);
                }
                else if (entercountdown < 2 && comboBox1.SelectedItem == "full text" && checkBox1senderauto.Checked == true && isslide.Checked == false)
                {
                    SendKeys.Send("{ENTER}");
                    entercountdown = (richTextBox1.TextLength);
                }

                if (comboBox1.SelectedItem == "each word" && checkBox1senderauto.Checked == true)
                {
                    if (richTextBox1.SelectedText == " ")
                    {
                        SendKeys.Send("{BACKSPACE}");
                        SendKeys.Send("{ENTER}");
                    }
                }


                if (countdown < 1 && sendinfinite.Checked == false)
                {
                    stopspamming();
                }
                else if (sendinfinite.Checked == true && richTextBox1.SelectionStart == (richTextBox1.TextLength - 1))
                {
                    richTextBox1.SelectionStart = 0;
                    richTextBox1.SelectionLength = 1;
                }
                else if (sendinfinite.Checked == false && richTextBox1.SelectionStart == (richTextBox1.TextLength - 1))
                {
                    richTextBox1.SelectionStart = 0;
                    richTextBox1.SelectionLength = 1;
                }
            }
            else if (radioButton1.Checked == true)
            {
                if(comboBox2.SelectedItem == "From List")
                {

                    Random randomtext = new Random();

                    if(order > listBox1.Items.Count)
                    {
                        order = 0;
                    }
                    
                    if(ismultiplerandom.Checked == true)
                    {
                        SendKeys.Send(listBox1.Items[randomtext.Next(0, listBox1.Items.Count)].ToString());
                    }
                    else if (ismultiplerandom.Checked == false)
                    {
                        SendKeys.Send(listBox1.Items[randomtext.Next(0, listBox1.Items.Count)].ToString());
                    }

                    order += 1;

                    if(checkBox1senderauto.Checked == true)
                    {
                        SendKeys.Send("{ENTER}");
                    }
                    
                }
                else if(comboBox2.SelectedItem == "Random Numbers")
                {
                    
                    SendKeys.Send(rndnum.ToString());

                    if (comboBox1.SelectedItem == "each letter" && checkBox1senderauto.Checked == true || comboBox1.SelectedItem == "each word" && checkBox1senderauto.Checked == true || comboBox1.SelectedItem == "full text" && checkBox1senderauto.Checked == true)
                    {
                        SendKeys.Send("{ENTER}");
                    }

                }

            }

            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            startspam();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            startspam();
        }

        public void startspam()
        {
            if(isslide.Checked == false)
            {
                richTextBox1.Text += "#";
            }

            

            Random rndmsg = new Random();
            int msgindex = (rndmsg.Next(0, listBox1.Items.Count));
            debugtxtbox.Text = (listBox1.Items[msgindex].ToString());
            int lenght = debugtxtbox.TextLength;

            timer1.Interval = Convert.ToInt32(numericUpDown1.Value);
            countdown = (richTextBox1.TextLength * Convert.ToInt32(homanytimes.Value - 1));
            entercountdown = (richTextBox1.TextLength);
            richTextBox1.SelectionStart = 0;
            richTextBox1.SelectionLength = 1;
            stopspam.Visible = true;
            button1.Visible = false;
            timer1.Start();
        }

        private void stopspam_Click(object sender, EventArgs e)
        {
            stopspamming();
        }

        public void stopspamming()
        {
            stopspam.Visible = false;
            button1.Visible = true;
            timer1.Stop();

            if(isslide.Checked == false)
            {
                //richTextBox1.Focus();
                //SendKeys.Send("{BACKSPACE}");
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton1.Checked == true)
            {
                comboBox2.Enabled = true;
                label6.Enabled = true;
            }
            else
            {
                comboBox2.Enabled = false;
                label6.Enabled = false;
            }
        }

        public bool listopened = false;

        private void msed_Click(object sender, EventArgs e)
        {
            if(listopened == true)
            {
                this.Size = new System.Drawing.Size(578, 251);
                msed.Text = "MSGeditor >";
                listopened = false;
            }
            else
            {
                this.Size = new System.Drawing.Size(818, 251);
                msed.Text = "MSGeditor <";
                listopened = true;
            }

        }

        private void addlist_Click(object sender, EventArgs e)
        {
            

            if(multiplemessageinput.TextLength != 0 && multiplemessageinput.Text != " ")
            {
                listBox1.Items.Add(multiplemessageinput.Text);
                multiplemessageinput.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Restart();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.youtube.com/channel/UCM9q2NDkEB99gAJ8JV0pVNQ/featured");
        }
    }
}
