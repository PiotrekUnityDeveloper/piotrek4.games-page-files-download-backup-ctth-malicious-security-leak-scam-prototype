MINECRAFT MUST BE RUNNING OR IT WILL CRASH

How to inject client into minecraft:
1. Download forge installer from here:
https://maven.minecraftforge.net/net/minecraftforge/forge/1.12.2-14.23.5.2859/forge-1.12.2-14.23.5.2859-installer.jar
2. Run the installer
3. When it finishes, run minecraft forge version that you just installed
4. Once minecraft loads up, launch inject.exe and wait at around 30 seconds
(WARNING: run inject.exe ONLY if minecraft is fully loaded! Dont run it WHILE minecraft loads stuff)

check out my channel for more cracks!
https://www.youtube.com/channel/UCM9q2NDkEB99gAJ8JV0pVNQ/videos